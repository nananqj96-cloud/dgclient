plugins {
    id("fabric-loom") version "1.17.13"
}

version = property("mod_version") as String
group = "dev.vulxts"

base {
    archivesName.set("vulxtsclient")
}

repositories {
    mavenCentral()
}

dependencies {
    minecraft("com.mojang:minecraft:${property("minecraft_version")}")
    mappings(loom.officialMojangMappings())
    modImplementation("net.fabricmc:fabric-loader:${property("loader_version")}")
    modImplementation("net.fabricmc.fabric-api:fabric-api:${property("fabric_api_version")}")
    implementation(fileTree("src/main/resources/META-INF/jars") { include("*.jar") })
}

tasks.processResources {
    exclude("credits.txt", "**/credits.txt")
}

tasks.withType<Jar>().configureEach {
    exclude("credits.txt", "**/credits.txt")
}

tasks.jar {
    archiveClassifier.set("dev")
}

tasks.named<net.fabricmc.loom.task.RemapJarTask>("remapJar") {
    archiveFileName.set("vulxts-client-deobf-built.jar")
}

tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
    options.release.set(21)
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(21))
    withSourcesJar()
}

tasks.named<Jar>("sourcesJar") {
    duplicatesStrategy = DuplicatesStrategy.EXCLUDE
}
