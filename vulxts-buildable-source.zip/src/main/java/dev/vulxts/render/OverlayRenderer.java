package dev.vulxts.render;

import com.mojang.blaze3d.opengl.GlTexture;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.textures.GpuTexture;
import dev.vulxts.VulxtsClient;
import dev.vulxts.hud.HudDragController;
import dev.vulxts.hud.HudManager;
import dev.vulxts.module.impl.CustomCrosshairModule;
import dev.vulxts.module.impl.MotionBlurModule;
import dev.vulxts.notification.NotificationManager;
import dev.vulxts.render.nanovg.GlStateSnapshot;
import dev.vulxts.render.nanovg.NVGRenderer;
import dev.vulxts.theme.Theme;
import dev.vulxts.util.Colors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ChatScreen;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.options.OptionsSubScreen;
import org.lwjgl.opengl.GL33C;

public final class OverlayRenderer {
   private static HudManager hudManager;
   private static NotificationManager notifications;
   private static int fbo = -1;
   private static boolean crashed;

   private OverlayRenderer() {
   }

   public static void init(HudManager var0, NotificationManager var1) {
      hudManager = var0;
      notifications = var1;
   }

   public static float uiScale() {
      Minecraft var0 = Minecraft.getInstance();
      return Math.max(1.0F, (float)var0.getWindow().getHeight() / 1080.0F);
   }

   public static void render() {
      try {
         GlintTextureTinter.tick();
      } catch (Throwable var21) {
      }

      if (!crashed && hudManager != null) {
         Minecraft var2 = Minecraft.getInstance();
         RenderTarget var3 = var2.getMainRenderTarget();
         GpuTexture var1;
         if (var3 != null && (var1 = var3.getColorTexture()) instanceof GlTexture) {
            GlTexture var4 = (GlTexture)var1;
            boolean var5 = var2.screen instanceof NvgDrawable;
            boolean var6 = var2.screen instanceof ChatScreen;
            boolean var7 = var2.screen instanceof PauseScreen || var2.screen instanceof OptionsSubScreen;
            boolean var8 = !var2.options.hideGui && var2.level != null && !var5 && !var7;
            boolean var9 = var2.level != null && !var2.options.hideGui && !var7;
            MotionBlurModule var10 = VulxtsClient.modules() != null ? VulxtsClient.modules().motionBlur : null;
            boolean var0 = var10 != null && var10.isEnabled() && var2.level != null && !var5;
            if (var5 || var8 || var9 || var0) {
               try {
                  GlStateSnapshot var12 = GlStateSnapshot.capture();

                  try {
                     if (bindOverlayFbo(var4, var3.width, var3.height)) {
                        NVGRenderer var13 = NVGRenderer.get();
                        if (var0) {
                           MotionBlurRenderer.render(var13, var3.width, var3.height, var10);
                        }

                        var13.setFontMode(VulxtsClient.modules().clickGui.font.get());
                        if (!var13.hasFont()) {
                           return;
                        }

                        float var14 = uiScale();
                        float var15 = (float)var3.width / var14;
                        float var16 = (float)var3.height / var14;
                        var13.beginFrame((float)var3.width, (float)var3.height, 1.0F);
                        var13.save();
                        var13.scale(var14);
                        if (var8) {
                           if (var6 && HudDragController.isDragging()) {
                              HudDragController.updateDrag(var13);
                           }

                           CustomCrosshairModule var17;
                           if ((var17 = VulxtsClient.modules().customCrosshair).isEnabled() && var2.screen == null) {
                              var17.render(var13, var15 / 2.0F, var16 / 2.0F);
                           }

                           if (var2.screen == null) {
                              WorldNametagRenderer.render(var13);
                              NetheriteProbabilityRenderer.renderLabels(var13);
                           }

                           hudManager.render(var13, var15, var16);
                           if (var6) {
                              renderChatEditOverlay(var13, var15, var16);
                           }
                        }

                        if (var9) {
                           notifications.renderToasts(var13, var15, var16);
                        }

                        if (var5) {
                           ((NvgDrawable)var2.screen).renderNvg(var13, uiMouseX(), uiMouseY(), var15, var16);
                        }

                        var13.restore();
                        var13.endFrame();
                        return;
                     }
                  } finally {
                     var12.restore();
                  }

                  return;
               } catch (Throwable var23) {
                  crashed = true;
                  VulxtsClient.LOGGER.error("VulxtsClient overlay renderer crashed; disabling overlay", var23);
               }
            }
         }
      }
   }

   private static void renderChatEditOverlay(NVGRenderer var0, float var1, float var2) {
      Theme var3 = VulxtsClient.themes().current();
      float var4 = uiMouseX();
      float var5 = uiMouseY();
      String var6 = "VULXTS CLIENT  /  DRAG TO MOVE  /  SCROLL TO SCALE";
      var0.text(var6, (var1 - var0.textWidth(var6, 14.0F)) / 2.0F, 22.0F, 14.0F, Colors.withAlpha(var3.textMuted(), 0.9F));

      for (HudManager.Placement var8 : hudManager.layout(var0, var1, var2, true)) {
         boolean var10 = !var8.component().visible();
         boolean var9 = var8.contains(var4, var5) || var8.component() == HudDragController.draggedComponent();
         if (var10) {
            var0.save();
            var0.alpha(0.35F);
            hudManager.renderPlacement(var0, var8);
            var0.restore();
         }

         int var12 = var9 ? var3.accentBright() : Colors.withAlpha(var3.accent(), 0.5F);
         var0.rectOutline(var8.x() - 3.0F, var8.y() - 3.0F, var8.w() + 6.0F, var8.h() + 6.0F, 6.0F, var9 ? 1.6F : 1.0F, var12);
         var0.rect(var8.x() + var8.w() - 2.0F, var8.y() + var8.h() - 2.0F, 6.0F, 6.0F, 2.0F, var12);
         if (var9) {
            String var13 = Math.round(var8.component().getScale() * 100.0F) + "%";
            var0.text(var13, var8.x() + var8.w() + 6.0F, var8.y() + var8.h() / 2.0F, 11.0F, var3.accentBright());
         }
      }
   }

   private static boolean bindOverlayFbo(GlTexture var0, int var1, int var2) {
      if (fbo == -1) {
         fbo = GL33C.glGenFramebuffers();
      }

      GL33C.glBindFramebuffer(36160, fbo);
      GL33C.glFramebufferTexture2D(36160, 36064, 3553, var0.glId(), 0);
      if (GL33C.glCheckFramebufferStatus(36160) != 36053) {
         return false;
      } else {
         GL33C.glViewport(0, 0, var1, var2);
         GL33C.glDisable(3089);
         return true;
      }
   }

   public static float uiMouseX() {
      Minecraft var0 = Minecraft.getInstance();
      return (float)(var0.mouseHandler.xpos() * (double)var0.getWindow().getWidth() / (double)Math.max(1, var0.getWindow().getScreenWidth())) / uiScale();
   }

   public static float uiMouseY() {
      Minecraft var0 = Minecraft.getInstance();
      return (float)(var0.mouseHandler.ypos() * (double)var0.getWindow().getHeight() / (double)Math.max(1, var0.getWindow().getScreenHeight())) / uiScale();
   }

   public static float guiToUi(double var0) {
      Minecraft var2 = Minecraft.getInstance();
      float var3 = (float)(var0 * (double)var2.getWindow().getGuiScale());
      return var3 / uiScale();
   }

   public static float uiWidth() {
      Minecraft var0 = Minecraft.getInstance();
      return (float)var0.getWindow().getWidth() / uiScale();
   }

   public static float uiHeight() {
      Minecraft var0 = Minecraft.getInstance();
      return (float)var0.getWindow().getHeight() / uiScale();
   }
}
