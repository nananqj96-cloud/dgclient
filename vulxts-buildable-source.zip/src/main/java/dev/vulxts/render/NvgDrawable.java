package dev.vulxts.render;

import dev.vulxts.render.nanovg.NVGRenderer;

public interface NvgDrawable {
   void renderNvg(NVGRenderer nVGRenderer, float f, float g, float h, float i);
}
