package dev.vulxts.render;

record ClusterEspRenderer$Bucket(int x, int y, int z) {
   static ClusterEspRenderer$Bucket of(BlockEspRenderer.Hit var0, int var1) {
      return new ClusterEspRenderer$Bucket(Math.floorDiv(var0.x(), var1), Math.floorDiv(var0.y(), var1), Math.floorDiv(var0.z(), var1));
   }
}
