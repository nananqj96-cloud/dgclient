package dev.vulxts.gui;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.vulxts.module.Category;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class ClickGuiState {
   public static final String THEMES_PANEL = "__themes__";
   private final Map<String, ClickGuiState.PanelState> panels = new LinkedHashMap<>();
   private final Set<String> expandedModules = new HashSet<>();
   private final Set<String> favourites = new HashSet<>();
   private boolean laidOut;
   private boolean customized;
   private float lastLayoutWidth = -1.0F;
   private float lastLayoutHeight = -1.0F;
   private static final int LAYOUT_VERSION = 3;
   private static final float PANEL_W = 210.0F;
   private static final float SEARCH_W = 280.0F;

   public boolean isFavourite(String var1) {
      return this.favourites.contains(var1);
   }

   public void toggleFavourite(String var1) {
      if (!this.favourites.remove(var1)) {
         this.favourites.add(var1);
      }
   }

   public void markCustomized() {
      this.customized = true;
   }

   public ClickGuiState() {
      float var1 = 16.0F;

      for (Category var5 : Category.values()) {
         this.panels.put(var5.name(), new ClickGuiState.PanelState(var1, 16.0F));
         var1 += 222.0F;
      }

      this.panels.put("__themes__", new ClickGuiState.PanelState(var1, 320.0F));
   }

   public void ensureDefaultLayout(float var1, float var2) {
      if (!this.customized && (!this.laidOut || var1 != this.lastLayoutWidth || var2 != this.lastLayoutHeight)) {
         this.laidOut = true;
         this.lastLayoutWidth = var1;
         this.lastLayoutHeight = var2;
         String[] var3 = new String[]{
            Category.COMBAT.name(),
            Category.MISC.name(),
            Category.RENDER.name(),
            Category.VISUALS.name(),
            Category.CLIENT.name(),
            "__themes__"
         };
         float var4 = 1344.0F;
         if (var1 >= var4) {
            float var5;
            float var6 = var5 = (var1 - 1260.0F) / 7.0F;

            for (int var7 = 0; var7 < var3.length; var7++) {
               ClickGuiState.PanelState var8 = this.panel(var3[var7]);
               var8.x = var6;
               var8.y = 76.0F;
               var8.collapsed = false;
               var6 += 210.0F + var5;
            }
         } else {
            float var9 = 222.0F;
            int var10 = Math.max(1, (int)((var1 - 24.0F) / var9));

            for (int var11 = 0; var11 < var3.length; var11++) {
               ClickGuiState.PanelState var12 = this.panel(var3[var11]);
               var12.x = 12.0F + (float)(var11 % var10) * var9;
               var12.y = 76.0F + (float)(var11 / var10) * var2 * 0.4F;
               var12.collapsed = var11 / var10 > 0;
            }
         }
      }
   }

   public ClickGuiState.PanelState panel(String var1) {
      return this.panels.computeIfAbsent(var1, var0 -> new ClickGuiState.PanelState(16.0F, 16.0F));
   }

   public boolean isExpanded(String var1) {
      return this.expandedModules.contains(var1);
   }

   public void setExpanded(String var1, boolean var2) {
      if (var2) {
         this.expandedModules.add(var1);
      } else {
         this.expandedModules.remove(var1);
      }
   }

   public JsonObject toJson() {
      JsonObject var1 = new JsonObject();
      JsonArray var2 = new JsonArray();
      this.favourites.stream().sorted().forEach(var2::add);
      var1.add("favourites", var2);
      var1.addProperty("v", 3);
      var1.addProperty("custom", this.customized);

      for (Entry var4 : this.panels.entrySet()) {
         JsonObject var5 = new JsonObject();
         var5.addProperty("x", ((ClickGuiState.PanelState)var4.getValue()).x);
         var5.addProperty("y", ((ClickGuiState.PanelState)var4.getValue()).y);
         var5.addProperty("collapsed", ((ClickGuiState.PanelState)var4.getValue()).collapsed);
         var1.add((String)var4.getKey(), var5);
      }

      return var1;
   }

   public void fromJson(JsonObject var1) {
      this.favourites.clear();
      if (var1.has("favourites") && var1.get("favourites").isJsonArray()) {
         for (JsonElement var3 : var1.getAsJsonArray("favourites")) {
            if (var3.isJsonPrimitive() && var3.getAsJsonPrimitive().isString()) {
               this.favourites.add(var3.getAsString().replace("VulxtsJumpCircles@", "JumpCircles@"));
            }
         }
      }

      if (var1.has("v")
         && var1.get("v").getAsInt() >= 3
         && var1.has("custom")
         && var1.get("custom").getAsBoolean()) {
         this.laidOut = true;
         this.customized = true;

         for (Entry var6 : this.panels.entrySet()) {
            JsonObject var4 = var1.getAsJsonObject((String)var6.getKey());
            if (var4 != null) {
               if (var4.has("x")) {
                  ((ClickGuiState.PanelState)var6.getValue()).x = var4.get("x").getAsFloat();
               }

               if (var4.has("y")) {
                  ((ClickGuiState.PanelState)var6.getValue()).y = var4.get("y").getAsFloat();
               }

               if (var4.has("collapsed")) {
                  ((ClickGuiState.PanelState)var6.getValue()).collapsed = var4.get("collapsed").getAsBoolean();
               }
            }
         }
      }
   }

   public static class PanelState {
      public float x;
      public float y;
      public boolean collapsed;

      PanelState(float var1, float var2) {
         this.x = var1;
         this.y = var2;
      }
   }
}
