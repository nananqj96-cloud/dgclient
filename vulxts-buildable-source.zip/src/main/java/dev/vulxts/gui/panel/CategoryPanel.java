package dev.vulxts.gui.panel;

import dev.vulxts.gui.ClickGuiState;
import dev.vulxts.module.Category;
import dev.vulxts.module.Module;
import dev.vulxts.module.ModuleManager;
import dev.vulxts.render.nanovg.NVGIcons;
import dev.vulxts.render.nanovg.NVGRenderer;
import dev.vulxts.theme.ThemeManager;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class CategoryPanel extends Panel {
   private static final float ENTRY_GAP = 3.0F;
   private static final float ENTRY_INSET = 6.0F;
   private final Category category;
   private final List<ModuleEntry> entries = new ArrayList<>();
   private boolean favouritesOnly;
   private String filter = "";

   public void setFavouritesOnly(boolean var1) {
      this.favouritesOnly = var1;
   }

   public CategoryPanel(Category var1, ModuleManager var2, ThemeManager var3, ClickGuiState var4) {
      super(var3, var4.panel(var1.name()));
      this.category = var1;

      for (Module var6 : var2.inCategory(var1)) {
         this.entries.add(new ModuleEntry(var6, var3, var4));
      }
   }

   public void setFilter(String var1) {
      this.filter = var1 == null ? "" : var1.toLowerCase(Locale.ROOT).trim();
   }

   private List<ModuleEntry> visibleEntries() {
      return this.entries
         .stream()
         .filter(var1 -> !this.favouritesOnly || var1.isFavourite())
         .filter(var1 -> var1.getModule().getName().toLowerCase(Locale.ROOT).contains(this.filter))
         .sorted(Comparator.comparing(var0 -> !var0.isFavourite()))
         .toList();
   }

   @Override
   protected String title() {
      return this.category.getDisplayName();
   }

   @Override
   protected int icon() {
      return NVGIcons.get(this.category);
   }

   @Override
   protected float contentHeight(NVGRenderer var1) {
      if (this.visibleEntries().isEmpty()) {
         return 36.0F;
      } else {
         float var2 = 12.0F;

         for (ModuleEntry var4 : this.visibleEntries()) {
            var2 += var4.height(var1) + 3.0F;
         }

         return var2 - 3.0F;
      }
   }

   @Override
   protected void renderContent(NVGRenderer var1, float var2, float var3, float var4, float var5, float var6) {
      float var7 = var2;
      if (this.visibleEntries().isEmpty()) {
         var1.text(this.favouritesOnly ? "No favourites here" : "No matches", this.ps.x + 12.0F, var2 + 12.0F, 11.0F, this.theme().textDisabled());
      }

      float var8 = 198.0F;

      for (ModuleEntry var10 : this.visibleEntries()) {
         float var11 = var10.height(var1);
         var10.setBounds(this.ps.x + 6.0F, var7, var8);
         if (var7 + var11 >= var5 - 20.0F && var7 <= var6 + 20.0F) {
            float var12 = this.edgeFade(var7, var7 + var11, var5, var6);
            var10.render(var1, var3, var4, var12);
         }

         var7 += var11 + 3.0F;
      }
   }

   @Override
   public boolean mouseClicked(float var1, float var2, int var3) {
      for (ModuleEntry var5 : this.visibleEntries()) {
         if (var5.mouseClicked(var1, var2, var3)) {
            return true;
         }
      }

      return false;
   }

   @Override
   public void mouseDragged(float var1, float var2) {
      for (ModuleEntry var4 : this.visibleEntries()) {
         var4.mouseDragged(var1, var2);
      }
   }

   @Override
   public void mouseReleased() {
      for (ModuleEntry var2 : this.visibleEntries()) {
         var2.mouseReleased();
      }
   }

   @Override
   public boolean keyPressed(int var1) {
      for (ModuleEntry var3 : this.visibleEntries()) {
         if (var3.keyPressed(var1)) {
            return true;
         }
      }

      return false;
   }

   @Override
   public boolean charTyped(int var1) {
      for (ModuleEntry var3 : this.visibleEntries()) {
         if (var3.charTyped(var1)) {
            return true;
         }
      }

      return false;
   }

   @Override
   public boolean isListening() {
      for (ModuleEntry var2 : this.visibleEntries()) {
         if (var2.isListening()) {
            return true;
         }
      }

      return false;
   }
}
