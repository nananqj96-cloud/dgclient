package dev.vulxts.module.impl;

record SpawnerNametagsModule$ChunkPos(int x, int z) {
}
