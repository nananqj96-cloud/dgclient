package dev.vulxts.theme;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;

public class ThemeManager {
   public static final int PINK = -49508;
   private final List<Theme> themes = new ArrayList<>();
   private Theme current;

   public ThemeManager() {
      this.themes.add(new Theme("Slate", -9255492, false));
      this.themes.add(new Theme("Pink", -49508, false));
      this.themes.add(new Theme("Purple", -5743361, false));
      this.themes.add(new Theme("Blue", -11689985, false));
      this.themes.add(new Theme("Red", -45715, false));
      this.themes.add(new Theme("Emerald", -12654960, false));
      this.themes.add(new RainbowTheme());
      this.current = this.themes.getFirst();
   }

   public Theme current() {
      return this.current;
   }

   public List<Theme> getThemes() {
      return this.themes;
   }

   public void select(Theme var1) {
      if (this.themes.contains(var1)) {
         this.current = var1;
      }
   }

   public Theme addCustom(int var1) {
      int var2 = 1;

      for (Theme var4 : this.themes) {
         if (var4.isCustom()) {
            var2++;
         }
      }

      Theme var5 = new Theme("Custom " + var2, var1, true);
      this.themes.add(var5);
      return var5;
   }

   public void removeCustom(Theme var1) {
      if (var1.isCustom() && this.themes.remove(var1) && this.current == var1) {
         this.current = this.themes.getFirst();
      }
   }

   public JsonObject toJson() {
      JsonObject var1 = new JsonObject();
      var1.addProperty("current", this.current.getName());
      JsonArray var2 = new JsonArray();

      for (Theme var4 : this.themes) {
         if (var4.isCustom()) {
            JsonObject var5 = new JsonObject();
            var5.addProperty("name", var4.getName());
            var5.addProperty("accent", var4.accent());
            var2.add(var5);
         }
      }

      var1.add("custom", var2);
      return var1;
   }

   public void fromJson(JsonObject var1) {
      if (var1 != null) {
         this.themes.removeIf(Theme::isCustom);
         if (var1.has("custom")) {
            for (JsonElement var3 : var1.getAsJsonArray("custom")) {
               JsonObject var4 = var3.getAsJsonObject();
               this.themes
                  .add(new Theme(var4.get("name").getAsString(), var4.get("accent").getAsInt(), true));
            }
         }

         if (var1.has("current")) {
            String var5 = var1.get("current").getAsString();

            for (Theme var7 : this.themes) {
               if (var7.getName().equals(var5)) {
                  this.current = var7;
                  break;
               }
            }
         }
      }
   }
}
