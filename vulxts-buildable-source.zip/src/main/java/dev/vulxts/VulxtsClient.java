package dev.vulxts;

import dev.vulxts.config.ConfigManager;
import dev.vulxts.config.ConfigStore;
import dev.vulxts.gui.ClickGuiScreen;
import dev.vulxts.hud.HudManager;
import dev.vulxts.module.Category;
import dev.vulxts.module.ModuleManager;
import dev.vulxts.module.impl.FreecamModule;
import dev.vulxts.notification.NotificationManager;
import dev.vulxts.render.BlockEspRenderer;
import dev.vulxts.render.ClusterEspRenderer;
import dev.vulxts.render.MotionBlurRenderer;
import dev.vulxts.render.OverlayRenderer;
import dev.vulxts.render.StorageEspRenderer;
import dev.vulxts.render.SusChunkRenderer;
import dev.vulxts.spotify.SpotifyService;
import dev.vulxts.suschunk.ServerLightCache;
import dev.vulxts.theme.SoundSettings;
import dev.vulxts.theme.ThemeManager;
import dev.vulxts.util.UiSoundEvents;
import dev.vulxts.util.UiSounds;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.ClientStopping;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.StartTick;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Disconnect;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.Join;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterInit;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VulxtsClient implements ClientModInitializer {
   public static final String MOD_ID = "vulxtsclient";
   public static final String NAME = "Vulxts Client";
   public static final String VERSION = "1.6.2";
   public static final Logger LOGGER = LoggerFactory.getLogger("VulxtsClient");
   private static ModuleManager modules;
   private static ThemeManager themes;
   private static ConfigManager config;
   private static ConfigStore configStore;
   private static HudManager hud;
   private static NotificationManager notifications;
   private static SpotifyService spotify;
   private static SoundSettings soundSettings;
   private static boolean startupSoundPlayed;

   public static ModuleManager modules() {
      return modules;
   }

   public static ThemeManager themes() {
      return themes;
   }

   public static ConfigManager config() {
      return config;
   }

   public static ConfigStore configStore() {
      return configStore;
   }

   public static HudManager hud() {
      return hud;
   }

   public static SpotifyService spotify() {
      return spotify;
   }

   public static SoundSettings sounds() {
      return soundSettings;
   }

   public static NotificationManager notifications() {
      return notifications;
   }

   public void onInitializeClient() {
      LOGGER.info("{} {} initializing", "Vulxts Client", "1.6.2");
      UiSoundEvents.bootstrap();
      themes = new ThemeManager();
      soundSettings = new SoundSettings();
      modules = new ModuleManager();
      spotify = new SpotifyService();
      notifications = new NotificationManager(themes, modules.hud);
      hud = new HudManager(modules, themes, spotify, notifications);
      config = new ConfigManager(modules, themes);
      config.addSection("hud", hud::toJson, hud::fromJson);
      config.addSection("panels", ClickGuiScreen.state()::toJson, ClickGuiScreen.state()::fromJson);
      config.addSection("sounds", soundSettings::toJson, soundSettings::fromJson);
      config.load();
      configStore = new ConfigStore(config);
      configStore.loadAll();
      UiSounds.init(soundSettings);
      modules.setOpenGuiAction(() -> Minecraft.getInstance().setScreen(new ClickGuiScreen()));
      modules.setToggleListener((var0, var1) -> {
         if (!ConfigStore.applying && var0.getCategory() != Category.CLIENT && Minecraft.getInstance().level != null && modules.hud.notifications.get()) {
            notifications.push(var0.getName(), var1);
            UiSounds.notification(var1);
         }
      });
      OverlayRenderer.init(hud, notifications);
      ScreenEvents.AFTER_INIT.register((AfterInit)(var0, var1, var2, var3) -> {
         if (var1 instanceof TitleScreen && !startupSoundPlayed) {
            startupSoundPlayed = true;
            UiSounds.playStartup();
         }
      });
      spotify.start();
      ClientPlayConnectionEvents.JOIN.register((Join)(var0, var1, var2) -> clearSusState());
      ClientPlayConnectionEvents.DISCONNECT.register((Disconnect)(var0, var1) -> clearSusState());
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)var0 -> modules.onTick());
      ClientTickEvents.START_CLIENT_TICK.register((StartTick)var0 -> {
         FreecamModule var1 = modules.freecam;
         if (var1 != null && var1.isActive()) {
            FreecamModule.reapplyBodyInput(var0);
         }

         modules.onCombatTick();
      });
      ClientLifecycleEvents.CLIENT_STOPPING.register((ClientStopping)var0 -> {
         config.save();
         spotify.stop();
      });
   }

   private static void clearSusState() {
      BlockEspRenderer.clear();
      ClusterEspRenderer.clear();
      StorageEspRenderer.clear();
      ServerLightCache.get().clear();
      modules.susChunkFinder.scanner.clear();
      SusChunkRenderer.reset();
      if (modules.chunkFinder != null) {
         modules.chunkFinder.clear();
      }

      if (modules.spawnerNametags != null) {
         modules.spawnerNametags.clear();
      }

      if (modules.jumpCircles != null) {
         modules.jumpCircles.clear();
      }

      if (modules.hitParticles != null) {
         modules.hitParticles.clear();
      }

      if (modules.customAccessories != null) {
         modules.customAccessories.clear();
      }

      MotionBlurRenderer.reset();
   }
}
