package dev.vulxts.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({Minecraft.class})
public interface MinecraftAccessor {
   @Accessor("rightClickDelay")
   void vulxtsclient$setRightClickDelay(int i);

   @Invoker("startAttack")
   boolean vulxtsclient$startAttack();

   @Invoker("startUseItem")
   void vulxtsclient$startUseItem();
}
