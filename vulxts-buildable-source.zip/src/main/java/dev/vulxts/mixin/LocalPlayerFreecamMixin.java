package dev.vulxts.mixin;

import dev.vulxts.module.impl.FreecamModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({LocalPlayer.class})
public abstract class LocalPlayerFreecamMixin {
   @Inject(
      method = {"aiStep"},
      at = {@At("HEAD")}
   )
   private void vulxtsclient$freecamReapplyBeforeAiStep(CallbackInfo ci) {
      this.vulxtsclient$reapply();
   }

   @Inject(
      method = {"sendPosition"},
      at = {@At("HEAD")}
   )
   private void vulxtsclient$freecamReapplyBeforeSendPosition(CallbackInfo ci) {
      this.vulxtsclient$reapply();
   }

   private void vulxtsclient$reapply() {
      LocalPlayer self = (LocalPlayer)(Object)this;
      Minecraft mc = Minecraft.getInstance();
      if (mc.player == self) {
         FreecamModule f = FreecamModule.get();
         if (f != null && f.isActive()) {
            FreecamModule.reapplyBodyInput(mc);
         }
      }
   }
}
