package dev.vulxts.mixin;

import dev.vulxts.VulxtsClient;
import dev.vulxts.module.ModuleManager;
import dev.vulxts.module.impl.NetheriteFinderModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({MultiPlayerGameMode.class})
public class MultiPlayerGameModeAttackMixin {
   @Unique
   private BlockPos vulxtsclient$pendingPlacement;
   @Unique
   private BlockPos vulxtsclient$pendingMinedDebris;

   @Inject(
      method = {"attack"},
      at = {@At("HEAD")}
   )
   private void vulxtsclient$onAttack(Player player, Entity target, CallbackInfo ci) {
      if (player == Minecraft.getInstance().player && target != player) {
         ModuleManager modules = VulxtsClient.modules();
         if (modules != null && modules.hitParticles != null && modules.hitParticles.isEnabled()) {
            modules.hitParticles.onHit(target);
         }
      }
   }

   @Inject(
      method = {"destroyBlock"},
      at = {@At("HEAD")}
   )
   private void vulxtsclient$beginBlockBreak(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
      this.vulxtsclient$pendingMinedDebris = null;
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null && mc.level.getBlockState(pos).is(Blocks.ANCIENT_DEBRIS)) {
         this.vulxtsclient$pendingMinedDebris = new BlockPos(pos.getX(), pos.getY(), pos.getZ());
      }
   }

   @Inject(
      method = {"destroyBlock"},
      at = {@At("RETURN")}
   )
   private void vulxtsclient$finishBlockBreak(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
      BlockPos mined = this.vulxtsclient$pendingMinedDebris;
      this.vulxtsclient$pendingMinedDebris = null;
      if (mined != null && Boolean.TRUE.equals(cir.getReturnValue())) {
         ModuleManager modules = VulxtsClient.modules();
         NetheriteFinderModule finder = modules == null ? null : modules.netheriteFinder;
         if (finder != null) {
            finder.recordMinedDebris(mined);
         }
      }
   }

   @Inject(
      method = {"useItemOn"},
      at = {@At("HEAD")}
   )
   private void vulxtsclient$beginPlacement(LocalPlayer player, InteractionHand hand, BlockHitResult hit, CallbackInfoReturnable<InteractionResult> cir) {
      this.vulxtsclient$pendingPlacement = null;
      Minecraft mc = Minecraft.getInstance();
      if (player == mc.player && mc.level != null) {
         if ((hand == InteractionHand.MAIN_HAND ? player.getMainHandItem() : player.getOffhandItem()).getItem() instanceof BlockItem) {
            BlockPos clicked = hit.getBlockPos();
            BlockPos target = mc.level.getBlockState(clicked).canBeReplaced() ? clicked : clicked.relative(hit.getDirection());
            this.vulxtsclient$pendingPlacement = new BlockPos(target.getX(), target.getY(), target.getZ());
         }
      }
   }

   @Inject(
      method = {"useItemOn"},
      at = {@At("RETURN")}
   )
   private void vulxtsclient$finishPlacement(LocalPlayer player, InteractionHand hand, BlockHitResult hit, CallbackInfoReturnable<InteractionResult> cir) {
      BlockPos target = this.vulxtsclient$pendingPlacement;
      this.vulxtsclient$pendingPlacement = null;
      if (target != null && cir.getReturnValue() != null && ((InteractionResult)cir.getReturnValue()).consumesAction()) {
         ModuleManager modules = VulxtsClient.modules();
         NetheriteFinderModule finder = modules == null ? null : modules.netheriteFinder;
         if (finder != null) {
            finder.recordPlayerPlacement(target);
         }
      }
   }
}
